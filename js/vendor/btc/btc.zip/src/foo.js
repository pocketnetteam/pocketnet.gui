
  bitcoin = require('./index');
  Buffer = require('buffer').Buffer
